package com.example.a3_buttons_bogdanov

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class SecondActivity : AppCompatActivity() {
    private lateinit var textview_random:TextView
    private lateinit var textview_label:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)

        textview_random=findViewById(R.id.textview_random)
        textview_label=findViewById(R.id.textview_label)

        showRandomNumber()
    }

    companion object{
        const val  TOTAL_COUNT = "total_count"
    }

    fun showRandomNumber (){
        val count = intent.getIntExtra(TOTAL_COUNT, 0)
        val random = Random(0)
        var randomInt = 0
        if (count > 0) {
            randomInt = random.nextInt(count + 1)
        }
        textview_random.text = Integer.toString(randomInt)
        textview_label.text = getString(R.string.random_heading, count)
    }

    fun backToMain(view: View) {
        finish() // закрывает SecondActivity, возврат на MainActivity
    }
}