package com.example.kval968_Bogdanov

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import kotlin.random.Random
import com.example.kval968_Bogdanov.R
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Random2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_random2)

        val textView = findViewById<TextView>(R.id.textViewRandom)
        val maxCount = intent.getIntExtra("count", 0)

        val randomNumber = Random.nextInt(0, maxCount)
        textView.text = randomNumber.toString()
    }
}