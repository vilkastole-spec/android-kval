package com.example.kval968_Bogdanov

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    fun menu_to_profile(view: View) {
        val menu_to_profile = Intent(this, Profile::class.java)
        startActivity(menu_to_profile)
    }
    fun menu_to_random(view: View) {
        val menu_to_random = Intent(this, Random1::class.java)
        startActivity(menu_to_random)
    }
    fun menu_to_media(view: View) {
        val menu_to_media = Intent(this, Media::class.java)
        startActivity(menu_to_media)
    }
    fun menu_exit(view: View) {
        finishAffinity()
    }
}