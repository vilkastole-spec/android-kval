package com.example.kval968_Bogdanov

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.kval968_Bogdanov.R
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Random1 : AppCompatActivity() {
    private lateinit var textView: TextView
    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_random1)
        textView = findViewById(R.id.textView4)
        textView.text = count.toString()
    }

    fun random_getnumber(view: View) {
        val intent = Intent(this, Random2::class.java)
        intent.putExtra("count", count)
        startActivity(intent)
    }

    fun random_plus(view: View) {
        count++
        textView.text = count.toString()
    }

    fun random_minus(view: View) {
        count--
        textView.text = count.toString()
    }
}